<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
    <div class="row d-flex justify-content-center">
        <div class="col-md-6 ">
            <div class="card">
                <div class="card-header">
                    <?php echo e($title); ?>

                </div>
                <div class="card-body">
                    <div class="row">

                        <form action="/contact" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="form-group mt-3">
                                <label for="name">Nama</label>
                                <input type="text" class="form-control" name="name"
                                    placeholder="Masukkan Nama ..." required>
                            </div>

                            <div class="form-group mt-3">
                                <label for="phone">No.Hp</label>
                                <input type="text" class="form-control" name="phone"
                                    placeholder="Masukkan No.Hp ..." required>
                            </div>
                            <div class="form-group mt-3 ">
                                <button type="submit" class="btn btn-primary btn-block">Simpan</button>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\ASUS-X441U\Music\kabel-telkom\resources\views/contact/create.blade.php ENDPATH**/ ?>