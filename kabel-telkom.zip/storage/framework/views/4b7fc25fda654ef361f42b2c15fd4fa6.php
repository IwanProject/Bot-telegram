<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-3">
    <div class="row d-flex justify-content-center">
        <div class="col-md-6 ">
            <div class="card">
                <div class="card-header">
                    <?php echo e($title); ?>

                </div>
                <div class="card-body">
                    <div class="row">

                        <form action="<?php echo e(route('contact.update', $contact->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group mt-3">
                                <label for="name">Nama</label>
                                <input type="text" class="form-control" name="name"
                                    placeholder="Masukkan Nama ..." value="<?php echo e($contact->name); ?>" required>
                            </div>

                            <div class="form-group mt-3">
                                <label for="phone">No.Hp</label>
                                <input type="text" class="form-control" name="phone"
                                    placeholder="Masukkan No.Hp ..." value="<?php echo e($contact->phone); ?>" required>
                            </div>
                            <div class="form-group mt-3 ">
                                <button type="submit" class="btn btn-warning btn-block">Update</button>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\ASUS-X441U\Music\kabel-telkom\resources\views/contact/edit.blade.php ENDPATH**/ ?>